
DINOS - Ready to Deploy (Vite + React)
=====================================

What's included
- React app with in-site editor (GrapesJS) and export via html2canvas
- Free plan: up to 3 downloads per email (tracked locally)
- Premium flow using Gumroad: https://dinosaurartistry.gumroad.com/l/gucjoj
- Logo included (public/logo.png)
- SEO meta tags and basic styles

Quick start (deploy to Vercel)
1. Unzip the package.
2. (Optional) Edit files: src/App.jsx to customize templates or replace Gumroad link.
3. Create a new GitHub repo and push the folder, or deploy directly to Vercel:
   - Go to https://vercel.com/ and log in with your dinosdesignsai@gmail.com Google account
   - Click "New Project" -> Import -> Upload (select this folder or ZIP)
   - Vercel will detect the project. Set framework to "Vite"
   - Deploy. Your site will be live like: https://your-project.vercel.app

Notes & Next steps
- For production-safe premium unlocking, configure Gumroad to redirect to:
  https://<your-site>/premium-dashboard?purchase_token=...
  Then verify the token server-side using Gumroad's API/webhook.
- The current free-limit logic uses localStorage. To enforce across devices, connect a server or Google Sheets + Apps Script.
- To enable ChatGPT-powered template generation, add a serverless endpoint that calls OpenAI API (keep API key server-side).

Enjoy! — I prepared this package for you; deploy it and you'll have DINOS live quickly.
