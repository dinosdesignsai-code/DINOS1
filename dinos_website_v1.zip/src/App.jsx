
import React, { useEffect, useRef, useState } from "react";
import grapesjs from "grapesjs";
import html2canvas from "html2canvas";

// Gumroad product link (set by Harshit)
const GUMROAD_PRODUCT_URL = "https://dinosaurartistry.gumroad.com/l/gucjoj";

// Sample templates
const SAMPLE_TEMPLATES = [
  {
    id: "resume-modern",
    title: "Modern Resume",
    premium: false,
    thumb: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='400'><rect width='100%' height='100%' fill='%23fff'/><text x='50' y='100' font-size='36' fill='%23000'>Modern Resume</text></svg>",
    html: `<div style='font-family:Inter,system-ui,Arial;max-width:800px;padding:36px;border:1px solid #e5e7eb'><h1 style='font-size:28px;margin:0'>Your Name</h1><p style='color:#6b7280'>Job Title · City</p><hr/><section><h3 style='margin-bottom:6px'>Experience</h3><div><strong>Role</strong> — Company<br/><small>2019–Present</small></div></section></div>`
  },
  {
    id: "insta-carousel",
    title: "Instagram Carousel",
    premium: true,
    thumb: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='400'><rect width='100%' height='100%' fill='%23000000'/><text x='50' y='200' font-size='36' fill='%23ffd700'>Premium Carousel</text></svg>",
    html: `<div style='width:800px;height:800px;background:#111;color:#fff;display:flex;align-items:center;justify-content:center;font-family:Inter,system-ui,Arial'><h1 style='font-size:48px'>Engaging Carousel</h1></div>`
  },
  {
    id: "business-card",
    title: "Business Card",
    premium: false,
    thumb: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='400'><rect width='100%' height='100%' fill='%23fff'/><text x='50' y='200' font-size='36' fill='%23000000'>Business Card</text></svg>",
    html: `<div style='width:350px;height:200px;border:1px solid #000;padding:16px;font-family:Inter,system-ui,Arial'><h3 style='margin:0'>Your Name</h3><p style='margin:0;color:#6b7280'>Role · Company</p></div>`
  }
];

export default function App() {
  const editorRef = useRef(null);
  const grapesRef = useRef(null);
  const [activeTemplate, setActiveTemplate] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [email, setEmail] = useState("");
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [downloadCount, setDownloadCount] = useState(0);
  const [userIsPremium, setUserIsPremium] = useState(false);

  useEffect(() => {
    const savedEmail = localStorage.getItem("dinos_email");
    if (savedEmail) setEmail(savedEmail);
    const savedCount = parseInt(localStorage.getItem(`dinos_count_${savedEmail}`) || "0", 10);
    setDownloadCount(isNaN(savedCount) ? 0 : savedCount);
    const premium = localStorage.getItem(`dinos_premium_${savedEmail}`) === "1";
    setUserIsPremium(premium);
  }, []);

  useEffect(() => {
    if (!showEditor) return;

    grapesRef.current = grapesjs.init({
      container: "#gjs",
      fromElement: false,
      height: "600px",
      width: "auto",
      storageManager: { type: null },
      panels: { defaults: [] }
    });

    grapesRef.current.BlockManager.add("text-block", {
      label: "Text",
      content: '<div style="padding:10px">Editable text</div>'
    });

    if (activeTemplate) {
      const html = activeTemplate.html;
      grapesRef.current.setComponents(html);
    }

    return () => {
      if (grapesRef.current) {
        grapesRef.current.destroy();
        grapesRef.current = null;
      }
    };

  }, [showEditor, activeTemplate]);

  const openTemplateInEditor = (template) => {
    if (template.premium && !userIsPremium) {
      if (!email) {
        setEmailModalOpen(true);
        return;
      }
      window.open(GUMROAD_PRODUCT_URL, "_blank");
      return;
    }

    setActiveTemplate(template);
    setShowEditor(true);
  };

  const saveEmailAndProceed = (proceedCallback) => {
    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      alert("Please enter a valid email (e.g. name@example.com)");
      return;
    }
    localStorage.setItem("dinos_email", email);
    if (!localStorage.getItem(`dinos_count_${email}`)) localStorage.setItem(`dinos_count_${email}`, "0");
    const premiumFlag = localStorage.getItem(`dinos_premium_${email}`) === "1";
    setUserIsPremium(premiumFlag);
    setEmailModalOpen(false);
    if (typeof proceedCallback === "function") proceedCallback();
  };

  const exportAsImage = async () => {
    if (!activeTemplate) return;
    const html = grapesRef.current.getHtml();
    const css = grapesRef.current.getCss();
    const wrapper = document.createElement("div");
    wrapper.style.position = "absolute";
    wrapper.style.left = "-9999px";
    wrapper.innerHTML = `<style>${css}</style>${html}`;
    document.body.appendChild(wrapper);

    try {
      const canvas = await html2canvas(wrapper, { scale: 2 });
      const dataUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `${activeTemplate.id}.png`;
      a.click();

      const savedEmail = localStorage.getItem("dinos_email");
      if (savedEmail && !userIsPremium) {
        const key = `dinos_count_${savedEmail}`;
        const cur = parseInt(localStorage.getItem(key) || "0", 10);
        const next = cur + 1;
        localStorage.setItem(key, String(next));
        setDownloadCount(next);
        if (next >= 3) {
          alert("You've reached the free limit of 3 downloads. Please upgrade to Premium to continue.");
        }
      }

    } catch (err) {
      console.error(err);
      alert("Failed to export. Try again or use a different browser.");
    } finally {
      if (wrapper.parentNode) wrapper.parentNode.removeChild(wrapper);
    }
  };

  const handleMakePremium = () => {
    window.open(GUMROAD_PRODUCT_URL, "_blank");
  };

  const markAsPremiumLocally = () => {
    const savedEmail = localStorage.getItem("dinos_email");
    if (!savedEmail) return alert("Please set your email first.");
    localStorage.setItem(`dinos_premium_${savedEmail}`, "1");
    setUserIsPremium(true);
    alert("Marked as premium locally. In production, hook this to your Gumroad webhook.");
  };

  return (
    <div className="min-h-screen bg-white text-black">
      <header className="bg-black text-white py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/logo.png" alt="DINOS logo" className="w-12 h-12 rounded" />
            <div>
              <h1 className="text-2xl font-bold">DINOS <span className="text-gold">Design With AI</span></h1>
              <p className="text-sm text-gray-300">AI-generated, fully editable templates — free & premium</p>
            </div>
          </div>
          <div className="flex gap-4 items-center">
            <button onClick={() => window.location.href = '#gallery'} className="px-4 py-2 border border-white rounded">Shop Templates</button>
            <button onClick={() => { if (!email) setEmailModalOpen(true); else window.open('#editor', '_self'); }} className="px-4 py-2 bg-gold text-black rounded">Create with AI</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section id="gallery">
          <h2 className="text-3xl font-bold mb-6">Template Gallery</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {SAMPLE_TEMPLATES.map(t => (
              <div key={t.id} className="border rounded overflow-hidden shadow p-4 relative">
                {t.premium && <div className="absolute top-3 right-3 bg-yellow-400 text-black text-xs px-2 py-1 rounded">Premium</div>}
                <img src={t.thumb} alt={t.title} className="w-full h-40 object-cover mb-3 bg-gray-100" />
                <h3 className="font-semibold">{t.title}</h3>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => { setActiveTemplate(t); setShowEditor(false); window.scrollTo({top:0,behavior:'smooth'}) }} className="px-3 py-2 border rounded">Preview</button>
                  <button onClick={() => openTemplateInEditor(t)} className="px-3 py-2 bg-black text-white rounded">Customize</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {activeTemplate && !showEditor && (
          <section className="mt-12">
            <h3 className="text-2xl font-bold">Preview: {activeTemplate.title}</h3>
            <div className="mt-4 border p-6 bg-gray-50">
              <div dangerouslySetInnerHTML={{ __html: activeTemplate.html }} />
              <div className="mt-4 flex gap-2">
                <button onClick={() => { if (!email) setEmailModalOpen(true); else openTemplateInEditor(activeTemplate); }} className="px-4 py-2 bg-black text-white rounded">Customize</button>
                <button onClick={() => { if (!email) setEmailModalOpen(true); else exportAsImage(); }} className="px-4 py-2 border rounded">Download</button>
              </div>
            </div>
          </section>
        )}

        {showEditor && (
          <section id="editor" className="mt-12">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-bold">Editor: {activeTemplate?.title}</h3>
              <div className="flex gap-2">
                <button onClick={() => exportAsImage()} className="px-4 py-2 bg-gold text-black rounded">Export as PNG</button>
                <button onClick={() => setShowEditor(false)} className="px-4 py-2 border rounded">Close Editor</button>
              </div>
            </div>
            <div id="gjs" ref={editorRef} className="border" />
            <div className="mt-3">
              <p className="text-sm">Tip: Use blocks to add text or images. The editor is simplified for demo — extend it with plugins for fonts, icons, and stock images.</p>
            </div>
          </section>
        )}

        <aside className="mt-12 border p-6 rounded bg-gray-50">
          <h4 className="font-semibold">Account</h4>
          <p className="text-sm mt-2">Email: <strong>{email || 'Not set'}</strong></p>
          <p className="text-sm mt-1">Downloads used: <strong>{downloadCount}</strong> / 3 (free)</p>
          <div className="mt-4 flex gap-2">
            <button onClick={() => setEmailModalOpen(true)} className="px-3 py-2 border rounded">Set Email</button>
            <button onClick={handleMakePremium} className="px-3 py-2 bg-black text-white rounded">Upgrade to Premium</button>
            <button onClick={markAsPremiumLocally} className="px-3 py-2 bg-yellow-400 rounded">(DEV) Mark Premium</button>
          </div>
          <p className="mt-3 text-xs text-gray-600">Premium unlocks all templates, removes download limits, and gives access to premium editor tools.</p>
        </aside>

      </main>

      <footer className="bg-black text-white py-6 mt-12">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <p>Contact: dinosdesignsai@gmail.com</p>
          <p className="text-xs mt-2">© {new Date().getFullYear()} DINOS — Design With AI</p>
        </div>
      </footer>

      {emailModalOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
          <div className="bg-white p-6 rounded max-w-md w-full">
            <h4 className="font-bold">Enter your email to continue</h4>
            <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" className="w-full border mt-3 p-2 rounded" />
            <div className="mt-4 flex gap-2 justify-end">
              <button onClick={() => setEmailModalOpen(false)} className="px-3 py-2 border rounded">Cancel</button>
              <button onClick={() => saveEmailAndProceed(() => { if (activeTemplate) openTemplateInEditor(activeTemplate); })} className="px-3 py-2 bg-black text-white rounded">Save & Continue</button>
            </div>
            <p className="text-xs mt-2">We will track your free downloads by this email. To get premium access, purchase from Gumroad.</p>
          </div>
        </div>
      )}

      <style>{`.text-gold{color:#d4af37}.bg-gold{background:#d4af37}.border-gold{border-color:#d4af37}`}</style>
    </div>
  );
}
